#include<bits/stdc++.h>
using namespace std;
int tab[100];

int main() {
	for (int i = 0; i <= 100; i++)
		tab[i] = i;
}



