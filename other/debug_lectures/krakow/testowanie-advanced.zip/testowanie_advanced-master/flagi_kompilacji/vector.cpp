#include<bits/stdc++.h>
using namespace std;

int main() {
	vector<int> v(10);
	cout << v[10];
}



