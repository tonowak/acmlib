#include<bits/stdc++.h>
using namespace std;
int tab[100];

int main() {
	int x = 1;
	if (x = 2) {
		cout << x;
	}
}



