#include<bits/stdc++.h>
using namespace std;

int main() {
    long long x = 7;
    cout << max(x, 0) << endl;
}
